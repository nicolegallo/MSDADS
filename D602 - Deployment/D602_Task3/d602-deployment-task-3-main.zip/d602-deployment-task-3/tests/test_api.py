# tests/test_api.py
import importlib.util
from fastapi.testclient import TestClient

def _load_app():
    """
    Import the FastAPI app regardless of file name.
    Prefers api_python.py; falls back to api_python.py if present.
    """
    try:
        from api_python import app
        return app
    except Exception:
        spec = importlib.util.spec_from_file_location("api", "api_python.py")
        if spec and spec.loader:
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return m.app
        raise

app = _load_app()
client = TestClient(app)

def test_root_ok():
    r = client.get("/")
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, dict)
    assert "message" in data

def test_predict_delays_ok():
    params = {"arrival": "ORD", "dep_local": "16:30", "arr_local": "19:30"}
    r = client.get("/predict/delays", params=params)
    assert r.status_code == 200
    data = r.json()
    assert "average_departure_delay_min" in data
    assert isinstance(data["average_departure_delay_min"], (int, float)) and not isinstance(
    data["average_departure_delay_min"], bool
)
    
def test_predict_delays_bad_time():
    params = {"arrival": "ORD", "dep_local": "notatime", "arr_local": "19:30"}
    r = client.get("/predict/delays", params=params)
    assert r.status_code == 422