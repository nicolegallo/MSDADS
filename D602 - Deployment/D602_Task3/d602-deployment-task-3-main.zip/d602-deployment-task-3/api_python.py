#!/usr/bin/env python
# coding: utf-8

# import statements
from fastapi import FastAPI, HTTPException, Query
import json
import numpy as np
import pickle
import datetime
import os

app = FastAPI(title="Flight Delay Predictor API", description="An API to predict flight delays based on departure and arrival times and airports.", version="1.0.0")

@app.get("/")
def read_root():
    return {"message": "API running. Use /predict/delays?arrival=...&dep_local=HH:MM&arr_local=HH:MM"}

# Import the airport encodings file
f = open('airport_encodings.json')
 
# returns JSON object as a dictionary
airports = json.load(f)

def create_airport_encoding(airport: str, airports: dict) -> np.array:
    """
    create_airport_encoding is a function that creates an array the length of all arrival airports from the chosen
    departure aiport.  The array consists of all zeros except for the specified arrival airport, which is a 1.  

    Parameters
    ----------
    airport : str
        The specified arrival airport code as a string
    airports: dict
        A dictionary containing all of the arrival airport codes served from the chosen departure airport
        
    Returns
    -------
    np.array
        A NumPy array the length of the number of arrival airports.  All zeros except for a single 1 
        denoting the arrival airport.  Returns None if arrival airport is not found in the input list.
        This is a one-hot encoded airport array.

    """
    temp = np.zeros(len(airports))
    if airport in airports:
        temp[airports.get(airport)] = 1
        temp = temp.T
        return temp
    else:
        return None

# TODO:  write the back-end logic to provide a prediction given the inputs
# requires finalized_model.pkl to be loaded 
# the model must be passed a NumPy array consisting of the following:
# (polynomial order, encoded airport array, departure time as seconds since midnight, arrival time as seconds since midnight)
# the polynomial order is 1 unless you changed it during model training in Task 2


MODEL_PATH = os.getenv("MODEL_PATH", "finalized_model.pkl")
POLY_ORDER = int(os.getenv("POLY_ORDER", "1"))

# Load model
_model = None
try:
    with open(MODEL_PATH, "rb") as f:
        _model = pickle.load(f)
except Exception:
    _model = None

def _parse_hhmm(t: str) -> datetime.datetime:
    # Accept HH:MM or HH:MM:SS (both are "local" times-of-day)
    try:
        if len(t) == 5:
            return datetime.datetime.strptime(t, "%H:%M")
        return datetime.datetime.strptime(t, "%H:%M:%S")
    except ValueError:
        raise HTTPException(status_code=422,
                            detail=f"Invalid time format: {t}. Use HH:MM or HH:MM:SS")

def _seconds_since_midnight(dt: datetime.datetime) -> int:
    return dt.hour * 3600 + dt.minute * 60 + dt.second


def predict_average_delay(arrival_airport: str, dep_local: str, arr_local: str) -> float:
    """
    Build features in the exact order required by the template:
    (POLY_ORDER, one-hot arrival airport, dep secs, arr secs)
    """
    if _model is None:
        raise HTTPException(status_code=500, detail=f"Model not loaded from {MODEL_PATH}")

    # Create one-hot encoding for arrival airport
    enc = create_airport_encoding(arrival_airport, airports)
    if enc is None:
        raise HTTPException(status_code=400,
                            detail=f"Unknown arrival airport '{arrival_airport}' for this departure hub")

    dep_dt = _parse_hhmm(dep_local)
    arr_dt = _parse_hhmm(arr_local)
    dep_sec = _seconds_since_midnight(dep_dt)
    arr_sec = _seconds_since_midnight(arr_dt)

    # Build feature array
    features = np.concatenate(([POLY_ORDER], enc, [dep_sec, arr_sec])).astype(float).reshape(1, -1)

    try:
        y = _model.predict(features)
        # Robustly extract a scalar even if predict() returns (1,) or (1,1)
        pred = float(np.asarray(y).reshape(-1)[0])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Model prediction failed: {str(e)}")

    return pred
    

# TODO:  write the API endpoints.  

@app.get("/predict/delays")
def predict_delays(
    arrival: str = Query(..., min_length=3, max_length=5, description="Arrival IATA code, e.g., ORD"),
    dep_local: str = Query(..., description="Local departure time HH:MM or HH:MM:SS"),
    arr_local: str = Query(..., description="Local arrival time HH:MM or HH:MM:SS"),
):
    avg = predict_average_delay(arrival, dep_local, arr_local)
    return {
        "average_departure_delay_min": avg,
        "inputs": {"arrival": arrival, "dep_local": dep_local, "arr_local": arr_local},
        "poly_order": POLY_ORDER
    }