import pandas as pd, logging
from pathlib import Path

IN_CSV = "data/raw/T_ONTIME_REPORTING.csv"
OUT_CSV = "data/processed/cleaned_data.csv"
LOG = "logs/import_data.log"

COLS_IN = [
    "YEAR","MONTH","DAY_OF_MONTH","DAY_OF_WEEK",
    "ORIGIN","DEST","CRS_DEP_TIME","DEP_TIME","DEP_DELAY",
    "CRS_ARR_TIME","ARR_TIME","ARR_DELAY"
]
RENAME = {
    "DAY_OF_MONTH":"DAY",
    "ORIGIN":"ORG_AIRPORT",
    "DEST":"DEST_AIRPORT",
    "CRS_DEP_TIME":"SCHEDULED_DEPARTURE",
    "DEP_TIME":"DEPARTURE_TIME",
    "DEP_DELAY":"DEPARTURE_DELAY",
    "CRS_ARR_TIME":"SCHEDULED_ARRIVAL",
    "ARR_TIME":"ARRIVAL_TIME",
    "ARR_DELAY":"ARRIVAL_DELAY",
}
INTS = ["YEAR","MONTH","DAY","DAY_OF_WEEK",
        "SCHEDULED_DEPARTURE","DEPARTURE_TIME","DEPARTURE_DELAY",
        "SCHEDULED_ARRIVAL","ARRIVAL_TIME","ARRIVAL_DELAY"]

def norm_hhmm(x):
    if pd.isna(x): return pd.NA
    try:
        x = int(x)
        if x == 2400: x = 0
        return int(f"{x:04d}")
    except Exception:
        return pd.NA

def main():
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=LOG, level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")

    df = pd.read_csv(IN_CSV, low_memory=False)
    logging.info("Loaded raw CSV: %s rows, %s cols", len(df), df.shape[1])

    missing = [c for c in COLS_IN if c not in df.columns]
    if missing:
        logging.error("Missing expected columns: %s", missing)
        raise SystemExit(f"Missing columns: {missing}")

    df = df[COLS_IN].rename(columns=RENAME)

    for c in INTS:
        if c in ("SCHEDULED_DEPARTURE","DEPARTURE_TIME","SCHEDULED_ARRIVAL","ARRIVAL_TIME"):
            df[c] = df[c].apply(norm_hhmm)
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("Int64")

    df["ORG_AIRPORT"] = df["ORG_AIRPORT"].astype(str)
    df["DEST_AIRPORT"] = df["DEST_AIRPORT"].astype(str)

    # drop rows missing any required downstream fields
    before = len(df)
    df = df.dropna(subset=["YEAR","MONTH","DAY","DAY_OF_WEEK",
                           "ORG_AIRPORT","DEST_AIRPORT",
                           "SCHEDULED_DEPARTURE","SCHEDULED_ARRIVAL","DEPARTURE_DELAY"])
    dropped = before - len(df)
    logging.info("Dropped %d rows failing required-field check", dropped)

    # quick null report
    null_rates = (df.isna().mean()*100).round(2).to_dict()
    logging.info("Null rates (%%): %s", null_rates)

    df.to_csv(OUT_CSV, index=False)
    logging.info("Wrote %s with %d rows", OUT_CSV, len(df))
    print(f"Wrote {OUT_CSV} and {LOG}")

if __name__ == "__main__":
    main()