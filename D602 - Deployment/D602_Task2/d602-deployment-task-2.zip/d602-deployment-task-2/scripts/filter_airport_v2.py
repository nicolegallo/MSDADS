# Part C v2: filter + cleaning steps + month/year enforcement
import argparse, logging
from pathlib import Path
import pandas as pd

KEY_COLS = [
    "YEAR","MONTH","DAY","DAY_OF_WEEK",
    "ORG_AIRPORT","DEST_AIRPORT",
    "SCHEDULED_DEPARTURE","DEPARTURE_TIME","DEPARTURE_DELAY",
    "SCHEDULED_ARRIVAL","ARRIVAL_TIME","ARRIVAL_DELAY"
]

TIME_COLS = ["SCHEDULED_DEPARTURE","DEPARTURE_TIME","SCHEDULED_ARRIVAL","ARRIVAL_TIME"]

def norm_hhmm(x):
    if pd.isna(x): return pd.NA
    try:
        i = int(x)
        if i == 2400: i = 0
        hh, mm = divmod(i, 100)
        # invalid if minutes >= 60 or hours >= 24
        if not (0 <= hh <= 23 and 0 <= mm <= 59):
            return pd.NA
        return int(f"{hh:02d}{mm:02d}")
    except Exception:
        return pd.NA

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_csv", default="data/processed/cleaned_data.csv")
    ap.add_argument("--airport", default="ATL")
    ap.add_argument("--year", type=int, default=None, help="Optional: restrict to a single YEAR")
    ap.add_argument("--month", type=int, default=None, help="Optional: restrict to a single MONTH (1-12)")
    ap.add_argument("--out_csv", default="data/processed/cleaned_data.csv")  # overwrite so the model can read it
    ap.add_argument("--log_file", default="logs/filter_airport.log")
    return ap.parse_args()

def main():
    args = parse_args()
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=args.log_file, level=logging.INFO, filemode="w",
                        format="%(asctime)s %(levelname)s %(message)s")

    df = pd.read_csv(args.in_csv, low_memory=False)
    logging.info("Loaded %s with %d rows", args.in_csv, len(df))

    # Filter to chosen origin airport
    df = df[df["ORG_AIRPORT"] == args.airport].copy()
    logging.info("After airport filter (%s): %d rows", args.airport, len(df))

    # Cleaning: drop duplicate flights on key columns
    before = len(df)
    df = df.drop_duplicates(subset=["YEAR","MONTH","DAY","ORG_AIRPORT","DEST_AIRPORT",
                                    "SCHEDULED_DEPARTURE","SCHEDULED_ARRIVAL"])
    logging.info("Dropped %d duplicate rows", before - len(df))

    # Cleaning: validate & normalize HHMM time columns
    for c in TIME_COLS:
        df[c] = df[c].apply(norm_hhmm)
    time_nulls = df[TIME_COLS].isna().any(axis=1).sum()
    logging.info("Rows with invalid HHMM converted to NA in any time col: %d", time_nulls)

    # Enforce a single YEAR/MONTH to align with model assumption; if not provided, pick the most frequent
    if args.year is None:
        args.year = int(df["YEAR"].mode().iloc[0])
    if args.month is None:
        args.month = int(df["MONTH"].mode().iloc[0])
    df = df[(df["YEAR"] == args.year) & (df["MONTH"] == args.month)].copy()
    logging.info("Restricted to YEAR=%s, MONTH=%s → %d rows", args.year, args.month, len(df))

    # Final required non-null fields (defensive)
    req = ["YEAR","MONTH","DAY","DAY_OF_WEEK","ORG_AIRPORT","DEST_AIRPORT",
           "SCHEDULED_DEPARTURE","SCHEDULED_ARRIVAL","DEPARTURE_DELAY"]
    before = len(df)
    df = df.dropna(subset=req)
    logging.info("Dropped %d rows missing required fields", before - len(df))

    # Save as cleaned_data.csv so the model can read it directly
    df.to_csv(args.out_csv, index=False)
    logging.info("Wrote %s with %d rows", args.out_csv, len(df))
    print(f"✅ Part C v2 complete for {args.airport} {args.year}-{args.month:02d}")
    print(f"   Output: {args.out_csv}")
    print(f"   Log: {args.log_file}")

if __name__ == "__main__":
    main()