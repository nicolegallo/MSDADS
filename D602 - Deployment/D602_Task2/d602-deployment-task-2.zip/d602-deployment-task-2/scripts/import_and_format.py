import pandas as pd
from pathlib import Path

IN_CSV = "data/raw/T_ONTIME_REPORTING.csv"
OUT_CSV = "data/processed/cleaned_data.csv"

# BTS model schema mapping
COLS_IN = [
    "YEAR","MONTH","DAY_OF_MONTH","DAY_OF_WEEK",
    "ORIGIN","DEST","CRS_DEP_TIME","DEP_TIME","DEP_DELAY",
    "CRS_ARR_TIME","ARR_TIME","ARR_DELAY"
]
RENAME = {
    "DAY_OF_MONTH":"DAY",
    "ORIGIN":"ORG_AIRPORT",
    "DEST":"DEST_AIRPORT",
    "CRS_DEP_TIME":"SCHEDULED_DEPARTURE",
    "DEP_TIME":"DEPARTURE_TIME",
    "DEP_DELAY":"DEPARTURE_DELAY",
    "CRS_ARR_TIME":"SCHEDULED_ARRIVAL",
    "ARR_TIME":"ARRIVAL_TIME",
    "ARR_DELAY":"ARRIVAL_DELAY",
}

def main():
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(IN_CSV, low_memory=False)

    # select, rename
    df = df[COLS_IN].rename(columns=RENAME)

    # types: integers for time/labels, strings for airport codes
    int_cols = ["YEAR","MONTH","DAY","DAY_OF_WEEK",
                "SCHEDULED_DEPARTURE","DEPARTURE_TIME","DEPARTURE_DELAY",
                "SCHEDULED_ARRIVAL","ARRIVAL_TIME","ARRIVAL_DELAY"]
    for c in int_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce").astype("Int64")
    df["ORG_AIRPORT"] = df["ORG_AIRPORT"].astype(str)
    df["DEST_AIRPORT"] = df["DEST_AIRPORT"].astype(str)

    # drop rows missing required keys the model will need
    df = df.dropna(subset=["YEAR","MONTH","DAY","DAY_OF_WEEK",
                           "ORG_AIRPORT","DEST_AIRPORT",
                           "SCHEDULED_DEPARTURE","SCHEDULED_ARRIVAL","DEPARTURE_DELAY"])

    df.to_csv(OUT_CSV, index=False)
    print(f"Wrote {OUT_CSV} with {len(df):,} rows")

if __name__ == "__main__":
    main()
