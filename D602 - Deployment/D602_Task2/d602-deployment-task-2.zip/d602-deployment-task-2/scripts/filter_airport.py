# Part C v1: filter to one departure airport
import argparse
from pathlib import Path
import pandas as pd

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_csv", default="data/processed/cleaned_data.csv")
    ap.add_argument("--airport", default="ORD", help="Departure airport code")
    ap.add_argument("--out_csv", default="data/processed/airport_filtered.csv")
    return ap.parse_args()

def main():
    args = parse_args()
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.in_csv, low_memory=False)
    out = df[df["ORG_AIRPORT"] == args.airport].copy()

    out.to_csv(args.out_csv, index=False)
    print(f"✅ Filtered to {args.airport}: {len(out):,} rows → {args.out_csv}")

if __name__ == "__main__":
    main()
